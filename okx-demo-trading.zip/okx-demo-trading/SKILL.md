---
name: okx-demo-trading
description: "Use when the user asks to check OKX prices, view market data, check account balance, view positions, place swap/perpetual contract orders, set leverage, close positions, manage orders, or do anything related to OKX demo/simulated trading in Chinese or English. Trigger phrases include: 行情, 价格, 余额, 持仓, 下单, 开多, 开空, 买入, 卖出, 合约, 杠杆, 平仓, 撤单, K线, 模拟交易, buy BTC, sell ETH, long, short, leverage, positions, orders on OKX."
agent_created: true
license: MIT
metadata:
  author: workbuddy
  version: "1.0.0"
---

# OKX Demo Trading

Use the `okx` CLI to execute all OKX operations in demo/simulated trading mode.

## Prerequisites

The CLI and config are pre-installed:

- **CLI path**: `/Users/yyy/.workbuddy/binaries/node/workspace/node_modules/@okx_ai/okx-trade-cli/dist/index.js`
- **Node**: `/Users/yyy/.workbuddy/binaries/node/versions/22.12.0/bin/node`
- **NODE_PATH**: `/Users/yyy/.workbuddy/binaries/node/workspace/node_modules`
- **Config**: `~/.okx/config.toml` has a `demo` profile with `demo = true`
- **Account**: Demo funds (1 BTC, 1 ETH, 100 OKB, 5000 USDT)

## Running Commands

Always use this exact invocation format — the `--profile demo` flag ensures demo/simulated trading mode:

```bash
NODE_PATH=/Users/yyy/.workbuddy/binaries/node/workspace/node_modules \
/Users/yyy/.workbuddy/binaries/node/versions/22.12.0/bin/node \
/Users/yyy/.workbuddy/binaries/node/workspace/node_modules/@okx_ai/okx-trade-cli/dist/index.js \
--profile demo <module> <action> [args...]
```

Omit the `--json` flag for human-readable output. Add `--json` only when programmatic parsing is needed.

**Mode display**: After every command result, append `[模式: 模拟盘]` to remind the user.

## Key Commands

### Market Data
- `market ticker <instId>` — current price, 24h change
- `market candles <instId> --bar <1m|5m|15m|1H|4H|1D> --limit <N>` — K-lines
- `market orderbook <instId> --sz <N>` — order book depth
- `market instruments --instType SWAP` — all available swap contracts

### Account
- `account balance` — balance summary
- `account positions --instType SWAP` — open swap positions
- `account config` — account config (margin mode, leverage)

### Swap Trading (Perpetual Contracts)
- `swap place` — place order
- `swap close` — close position entirely
- `swap leverage` — set leverage
- `swap orders` — list orders
- `swap cancel` — cancel order
- `swap algo place` — place TP/SL algo order
- `swap algo trail` — trailing stop

## Quick Examples

```bash
# Check BTC swap price
okx --profile demo market ticker BTC-USDT-SWAP

# Check account
okx --profile demo account balance

# Market buy 1 ETH contract (long)
okx --profile demo swap place --instId ETH-USDT-SWAP --side buy --ordType market --sz 1 --tdMode cross --posSide long

# Market sell to close long
okx --profile demo swap close --instId BTC-USDT-SWAP --mgnMode cross --posSide long

# Set 10x leverage
okx --profile demo swap leverage --instId BTC-USDT-SWAP --lever 10 --mgnMode cross

# Limit order: buy 2 contracts at specific price
okx --profile demo swap place --instId BTC-USDT-SWAP --side buy --ordType limit --sz 2 --px 60000 --tdMode cross --posSide long

# Check open positions
okx --profile demo swap positions

# View K-line data
okx --profile demo market candles BTC-USDT-SWAP --bar 15m --limit 50
```

## Sz (Size) Guidance for Swaps

- `--sz` defaults to **contract count** (not USDT amount)
- 1 BTC-USDT-SWAP contract = 0.01 BTC
- 1 ETH-USDT-SWAP contract = 0.1 ETH
- Use `--tgtCcy quote_ccy` to specify USDT notional value instead of contract count
- Use `--tgtCcy margin` to specify USDT margin amount

## Important Rules

1. **Always use `--profile demo`** — this ensures simulated trading, no real funds
2. **Confirm before write** — for any order placement, confirm key params (instId, side, sz, type) with the user before executing
3. **Verify after write** — after placing orders, run a read command to confirm
4. **Show mode tag** — append `[模式: 模拟盘]` after every command output
5. **API key permissions** — current demo API key has "读取" (read) permission only; if placing orders fails with a permission error, guide the user to add "交易" (trade) permission to their OKX demo API key
6. **Handle errors** — if an order fails, read the error message and explain to the user in Chinese
